import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const [currentSection, setCurrentSection] = useState('name');

  const handlePress = () => {
    setCurrentSection(prevSection => {
      switch (prevSection) {
        case 'name':
          return 'education';
        case 'education':
          return 'about';
        case 'about':
          return 'contact';
        case 'contact':
          return 'name';
        default:
          return 'name';
      }
    });
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={handlePress} style={styles.contentContainer}>
          {currentSection === 'name' && (
            <View style = {styles.container}>
              <Image source={require('./assets/pic.jpg')} style = {styles.img}/>
              <Text style = {styles.head}>Maala Christian Paolo D.</Text>
              <Text style = {styles.par3}>ᴮᴬᶜᴴᴱᴸᴼᴿ ᴼᶠ ˢᶜᴵᴱᴺᶜᴱ ᴵᴺ ᴵᴺᶠᴼᴿᴹᴬᵀᴵᴼᴺ ᵀᴱᶜᴴᴺᴼᴸᴼᴳʸ</Text>
            </View>
          )}

          {currentSection === 'education' && (
            <View style = {styles.container}>
              <Text style = {styles.head2}>College</Text>
              <Text style = {styles.par}>Global Reciprocal College (2021 - Present)</Text>
              <Text style = {styles.head3}>Highschool</Text>
              <Text style = {styles.par}>San Diego Parochial School</Text>
              <Text style = {styles.head3}>Elementary</Text>
              <Text style = {styles.par}>San Diego Parochial School</Text>
            </View>
          )}

          {currentSection === 'about' && (
            <View style = {styles.container}>
              <Text style = {styles.head2}>About</Text>
              <Text style = {styles.par2}>
                Hello! My name is Maala Christian Paolo D. 28 years old and a 3rd year college student in Global Reciprocal Colleges  (GRC) . I live in Valenzuela City. I'am currently taking a Bachelor of Science in Information in Grc . I take up this course because it is a practical decision nowadays where everyone involves in technologies around the world . It will also help me to enhance my skill in web designing. Because of this course, it will help me to become a web designer someday.
              </Text>
            </View>
          )}

          {currentSection === 'contact' && (
            <View style = {styles.container}>
              <Text style = {styles.head2}>My Project</Text>
              <Image source = {require('./assets/project.png')} style = {styles.img}/>
              <Text style = {styles.head3}>Web Portfolio</Text>
            </View>
          )}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  contentContainer: {
    alignItems: 'center',
  },

  img: {
    height: 250,
    width: 250,
    borderRadius: 200
  },

  head: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 15,
  },

  head2: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },

  head3: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 30, 
    textAlign: 'center'
  },

  par: {
    fontSize: 13,
    textAlign: 'center',
  },

  par3: {
    fontSize: 20,
    textAlign: 'center',
  },

  par2: {
    fontSize: 15,
    marginTop: 15,
    paddingLeft: 30, 
    paddingRight: 30,
    textAlign: 'center'
  }
  
});

export default App;